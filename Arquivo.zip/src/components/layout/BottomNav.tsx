import type { Page } from '@/types'
import { cn } from '@/lib/utils'
import { 
  LayoutDashboard, 
  CreditCard, 
  ArrowLeftRight, 
  Tag, 
  BarChart3, 
  Settings,
  HandCoins,
} from 'lucide-react'

interface BottomNavProps {
  currentPage: Page
  onPageChange: (page: Page) => void
}

const navItems: { page: Page; label: string; icon: typeof LayoutDashboard }[] = [
  { page: 'dashboard', label: 'Início', icon: LayoutDashboard },
  { page: 'cartoes', label: 'Cartões', icon: CreditCard },
  { page: 'transacoes', label: 'Transações', icon: ArrowLeftRight },
  { page: 'categorias', label: 'Categorias', icon: Tag },
  { page: 'resumo', label: 'Resumo', icon: BarChart3 },
  { page: 'dividas', label: 'Dívidas', icon: HandCoins },
  { page: 'config', label: 'Config', icon: Settings },
]

export function BottomNav({ currentPage, onPageChange }: BottomNavProps) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-background border-t border-border safe-area-pb">
      <div className="flex items-center justify-around h-16 max-w-lg mx-auto px-1 overflow-x-auto">

        {navItems.map((item) => {
          const Icon = item.icon
          const isActive = currentPage === item.page
          
          return (
            <button
              key={item.page}
              onClick={() => onPageChange(item.page)}
              className={cn(
                'flex flex-col items-center justify-center gap-1 py-2 px-2 rounded-lg transition-colors min-w-[60px]',
                isActive 
                  ? 'text-primary bg-primary/10' 
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent'
              )}
            >
              <Icon className="h-5 w-5" />
              <span className="text-[10px] font-medium">{item.label}</span>
            </button>
          )
        })}

      </div>
    </nav>
  )
}
