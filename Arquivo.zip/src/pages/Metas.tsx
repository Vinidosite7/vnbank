import { useState } from "react"
import { useFinanceStore } from "@/store/finance-store"
import { PageWrapper } from "@/components/layout/PageWrapper"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Target, Trophy, Flame } from "lucide-react"
import { formatCurrency } from "@/lib/utils"

export default function MetasPage() {
  const { settings, updateSettings, getCurrentMonthProfit } = useFinanceStore()

  const [meta, setMeta] = useState(settings.meta || 10000)
  const [superMeta, setSuperMeta] = useState(settings.superMeta || 20000)

  const lucroAtual = getCurrentMonthProfit()

  const progressoMeta = Math.min((lucroAtual / meta) * 100, 100)
  const progressoSuper = Math.min((lucroAtual / superMeta) * 100, 100)

  const salvarMetas = () => {
    updateSettings({
      meta: Number(meta),
      superMeta: Number(superMeta),
    })
  }

  return (
    <PageWrapper title="Metas">

      {/* EDITAR METAS */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-sm text-muted-foreground">
            Definir Metas
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">

          <div>
            <label className="text-sm">Meta Mensal</label>
            <Input
              type="number"
              value={meta}
              onChange={(e) => setMeta(Number(e.target.value))}
            />
          </div>

          <div>
            <label className="text-sm">Super Meta</label>
            <Input
              type="number"
              value={superMeta}
              onChange={(e) => setSuperMeta(Number(e.target.value))}
            />
          </div>

          <Button onClick={salvarMetas} className="w-full">
            Salvar Metas
          </Button>

        </CardContent>
      </Card>

      {/* META NORMAL */}
      <Card className="mb-6">
        <CardHeader className="flex flex-row justify-between items-center">
          <CardTitle className="flex items-center gap-2 text-sm text-muted-foreground">
            <Target className="w-4 h-4" />
            Meta Mensal
          </CardTitle>

          {lucroAtual >= meta && (
            <Badge className="bg-green-500">
              Meta Batida 🎯
            </Badge>
          )}
        </CardHeader>

        <CardContent className="space-y-4">
          <p className="text-2xl font-bold">
            {formatCurrency(lucroAtual)}
          </p>

          <Progress value={progressoMeta} className="h-3" />

          <div className="text-xs text-muted-foreground flex justify-between">
            <span>Meta: {formatCurrency(meta)}</span>
            <span>
              {lucroAtual >= meta
                ? "Meta alcançada!"
                : `Faltam ${formatCurrency(meta - lucroAtual)}`}
            </span>
          </div>
        </CardContent>
      </Card>

      {/* SUPER META */}
      <Card className="border-yellow-500/30">
        <CardHeader className="flex flex-row justify-between items-center">
          <CardTitle className="flex items-center gap-2 text-sm text-muted-foreground">
            <Trophy className="w-4 h-4 text-yellow-500" />
            Super Meta
          </CardTitle>

          {lucroAtual >= superMeta && (
            <Badge className="bg-yellow-500 text-black">
              SUPER COTA 🏆
            </Badge>
          )}
        </CardHeader>

        <CardContent className="space-y-4">

          <Progress value={progressoSuper} className="h-3" />

          <div className="text-xs text-muted-foreground flex justify-between">
            <span>Super Meta: {formatCurrency(superMeta)}</span>
            <span>
              {lucroAtual >= superMeta
                ? "Super Meta conquistada!"
                : `Faltam ${formatCurrency(superMeta - lucroAtual)}`}
            </span>
          </div>

          {lucroAtual >= superMeta && (
            <div className="flex items-center gap-2 text-yellow-500 font-medium mt-2">
              <Flame className="w-4 h-4" />
              Você entrou no modo Super Empresário 🔥
            </div>
          )}

        </CardContent>
      </Card>

    </PageWrapper>
  )
}
